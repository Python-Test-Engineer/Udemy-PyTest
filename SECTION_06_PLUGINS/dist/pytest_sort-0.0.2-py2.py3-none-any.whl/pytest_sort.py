import pytest


def pytest_addoption(parser):
    parser.addoption(
        "--desc", action="store_true", default=False, help="sort descending"
    )
    parser.addoption("--asc", action="store_true", default=False, help="sort ascending")


def pytest_collection_modifyitems(items, config):

    if config.option.desc:
        items.sort(key=lambda item: item.nodeid.split("::")[-1], reverse=True)
        print(f"\n\n===> DESC:")
    if config.option.asc:
        items.sort(key=lambda item: item.nodeid.split("::")[-1])
        print(f"\n\n===> ASC:")
