def test_s():
    assert True


def test_z():
    assert True


def test_a():
    assert True


def test_y():
    assert True


def test_x():
    assert True


def test_r():
    assert True
